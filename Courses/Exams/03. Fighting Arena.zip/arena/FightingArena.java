package arena;

import java.util.ArrayList;
import java.util.List;

public class FightingArena {
    private List<Gladiator> gladiators;
    private String name;

    public FightingArena(String name) {
        this.gladiators = new ArrayList<>();
        this.name = name;
    }

    public void add(Gladiator gladiator) {
        this.gladiators.add(gladiator);
    }

    public void remove(String name) {
        for (Gladiator g : gladiators) {
            if (g.getName().equals(name)) {
                gladiators.remove(g);
                break;
            }
        }
    }

    public Gladiator getGladiatorWithHighestStatPower() {
        Gladiator bestGladiator = null;
        int highest = Integer.MIN_VALUE;

        for (Gladiator gladiator : gladiators) {
            int current = gladiator.getStatPower();

            if (current > highest) {
                bestGladiator = gladiator;
                highest = current;
            }
        }

        return bestGladiator;
    }

    public Gladiator getGladiatorWithHighestWeaponPower() {
        Gladiator bestGladiator = new Gladiator();
        int highest = Integer.MIN_VALUE;

        for (Gladiator gladiator : gladiators) {
            int current = gladiator.getWeaponPower();

            if (current > highest) {
                bestGladiator = gladiator;
                highest = current;
            }
        }

        return bestGladiator;
    }

    public Gladiator getGladiatorWithHighestTotalPower() {
        Gladiator bestGladiator = new Gladiator();
        int highest = Integer.MIN_VALUE;

        for (Gladiator gladiator : gladiators) {
            int current = gladiator.getTotalPower();

            if (current > highest) {
                bestGladiator = gladiator;
                highest = current;
            }
        }

        return bestGladiator;
    }

    public int getCount() {
        return this.gladiators.size();
    }

    public String getName() {
        return this.name;
    }

    @Override
    public String toString() {
        return String.format("%s – %d gladiators are participating.", getName(), getCount());
    }
}
