package healthyHeaven;

import java.util.LinkedList;
import java.util.List;

public class Salad {
    private String name;
    private List<Vegetable> products;

    public Salad(String name) {
        this.name = name;
        this.products = new LinkedList<>();
    }

    public String getName() {
        return name;
    }

    public int getTotalCalories() {
        int sum = 0;

        for (Vegetable product : products) {
            sum += product.getCalories();
        }

        return sum;
    }

    public int getProductCount() {
        return products.size();
    }

    public void add(Vegetable vegetable){
        products.add(vegetable);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        sb.append(String.format("* Salad %s is %d calories and have %d products:\n", getName(),getTotalCalories(),getProductCount()));
        for (int i = 0; i < getProductCount(); i++) {
            sb.append(products.get(i).toString());
            sb.append("\n");
        }

        return sb.toString();
    }
}
