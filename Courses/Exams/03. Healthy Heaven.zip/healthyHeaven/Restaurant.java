package healthyHeaven;

import java.util.LinkedList;
import java.util.List;

public class Restaurant {
    private String name;
    private List<Salad> data;

    public Restaurant(String name) {
        this.name = name;
        this.data = new LinkedList<>();
    }

    public void add(Salad salad) {
        data.add(salad);
    }

    public boolean buy(String name) {
        boolean containsSalad = false;

        for (Salad salad : data) {
            if (salad.getName().equals(name)) {
                data.remove(salad);
                containsSalad = true;
                break;
            }
        }

        return containsSalad;
    }

    public Salad getHealthiestSalad() {
        Salad healthiest = new Salad("");
        int leastCalories = Integer.MAX_VALUE;

        for (Salad salad : data) {
            int calories = salad.getTotalCalories();
            if (calories <= leastCalories) {
                healthiest = salad;
                leastCalories = calories;
            }
        }

        return healthiest;
    }

    public String getName() {
        return name;
    }

    public String generateMenu() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%s have %d salads:\n", getName(), data.size()));
        for (int i = 0; i < data.size(); i++) {
            sb.append(data.get(i).toString());
        }
        return sb.toString();
    }

}
