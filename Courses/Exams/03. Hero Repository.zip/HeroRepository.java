package heroRepository;

import java.util.ArrayList;
import java.util.List;

public class HeroRepository {
    private List<Hero> data;

    public HeroRepository() {
        this.data = new ArrayList<>();
    }

    public void add(Hero hero) {
        this.data.add(hero);
    }

    public void remove(String heroName) {
        for (Hero hero : data) {
            if (hero.getName().equals(heroName)) {
                this.data.remove(hero);
                break;
            }
        }
    }

    public Hero getHeroWithHighestStrength() {
        Hero best = new Hero();
        int highest = Integer.MIN_VALUE;

        for (Hero hero : data) {
            int currentItem = hero.getItem().getStrength();

            if (currentItem >= highest) {//check if >= or just >
                best = hero;
                highest = currentItem;
            }
        }

        return best;
    }

    public Hero getHeroWithHighestAgility() {
        Hero best = new Hero();
        int highest = Integer.MIN_VALUE;

        for (Hero hero : data) {
            int currentItem = hero.getItem().getAgility();

            if (currentItem >= highest) {//check if >= or just >
                best = hero;
                highest = currentItem;
            }
        }

        return best;
    }

    public Hero getHeroWithHighestIntelligence() {
        Hero best = new Hero();
        int highest = Integer.MIN_VALUE;

        for (Hero hero : data) {
            int currentItem = hero.getItem().getIntelligence();

            if (currentItem >= highest) {//check if >= or just >
                best = hero;
                highest = currentItem;
            }
        }

        return best;
    }

    public int getCount (){
        return this.data.size();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < this.data.size(); i++) {
            String s = this.data.get(i).toString();
            sb.append(s);
        }
        return sb.toString();
    }
}
