package heroRepository;

public class Hero {
    private String name;
    private int level;
    private Item item;

    public Hero(){
    }

    public Hero(String name, int level, Item item) {
        this.name = name;
        this.level = level;
        this.item = item;
    }

    public String getName() {
        return name;
    }

    public int getLevel() {
        return level;
    }

    public Item getItem() {
        return item;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Hero: ").append(getName()).append(" - ").append(getLevel()).append("\n");
        sb.append(" * Strength: ").append(getItem().getStrength());
        sb.append("\n");
        sb.append(" * Agility: ").append(getItem().getAgility());
        sb.append("\n");
        sb.append(" * Intelligence: ").append(getItem().getIntelligence());
        sb.append("\n");
        return sb.toString();
    }
}
