package heroRepository;

public class Item {
    private int strength;
    private int agility;
    private int intelligence;


    public Item (int strenght, int agility, int intelligence){
        this.strength = strenght;
        this.agility = agility;
        this.intelligence = intelligence;
    }

    public int getStrength(){
        return this.strength;
    }

    public int getAgility() {
        return this.agility;
    }

    public int getIntelligence() {
        return this.intelligence;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Item:\n");
        sb.append(" * Strength: ").append(getStrength());
        sb.append("\n");
        sb.append(" * Agility: ").append(getAgility());
        sb.append("\n");
        sb.append(" * Intelligence: ").append(getIntelligence());
        sb.append("\n");
        return sb.toString();
    }
}
